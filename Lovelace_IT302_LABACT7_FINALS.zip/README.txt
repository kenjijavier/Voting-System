admin login credentials:
username: admin
password Admin123

(to access user side right away. if not register when needed)
user login credentials:
email: qw@email.com
password: 123