﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Voting_System
{
    public partial class Usernavigation : Form
    {
        public Usernavigation()
        {
            InitializeComponent();
        }

        private void home_label_Click(object sender, EventArgs e)
        {
            Userhomepage f3 = new Userhomepage();
            f3.Show();
            this.Hide();
        }

        private void vote_label_Click(object sender, EventArgs e)
        {
            Vote v = new Vote();
            v.Show();
            this.Hide();
        }

        private void logout_label_Click(object sender, EventArgs e)
        {
            Userloginpage logout= new Userloginpage();
            logout.Show();
            this.Hide();
        }

        private void navigation_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are already in the Navigation Menu.");
        }
    }
}
