﻿namespace Voting_System
{
    partial class Admintabulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AdminNavigation = new System.Windows.Forms.Button();
            this.Tabtopred = new System.Windows.Forms.PictureBox();
            this.tabulationpage = new System.Windows.Forms.Label();
            this.label2__ = new System.Windows.Forms.Label();
            this.Prestag = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.vptag = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.sectag = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.auditag = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.Retrieve_tab = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Tabtopred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.SuspendLayout();
            // 
            // AdminNavigation
            // 
            this.AdminNavigation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.AdminNavigation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AdminNavigation.Location = new System.Drawing.Point(12, 18);
            this.AdminNavigation.Name = "AdminNavigation";
            this.AdminNavigation.Size = new System.Drawing.Size(47, 56);
            this.AdminNavigation.TabIndex = 22;
            this.AdminNavigation.Text = "___\r\n___\r\n___\r\n";
            this.AdminNavigation.UseVisualStyleBackColor = false;
            this.AdminNavigation.Click += new System.EventHandler(this.AdminNavigation_Click);
            // 
            // Tabtopred
            // 
            this.Tabtopred.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Tabtopred.Location = new System.Drawing.Point(-2, -6);
            this.Tabtopred.Name = "Tabtopred";
            this.Tabtopred.Size = new System.Drawing.Size(625, 98);
            this.Tabtopred.TabIndex = 21;
            this.Tabtopred.TabStop = false;
            // 
            // tabulationpage
            // 
            this.tabulationpage.AutoSize = true;
            this.tabulationpage.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabulationpage.Location = new System.Drawing.Point(27, 95);
            this.tabulationpage.Name = "tabulationpage";
            this.tabulationpage.Size = new System.Drawing.Size(251, 54);
            this.tabulationpage.TabIndex = 24;
            this.tabulationpage.Text = "Tabulation";
            // 
            // label2__
            // 
            this.label2__.AutoSize = true;
            this.label2__.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2__.Location = new System.Drawing.Point(3, 130);
            this.label2__.Name = "label2__";
            this.label2__.Size = new System.Drawing.Size(610, 36);
            this.label2__.TabIndex = 25;
            this.label2__.Text = "___________________________________";
            // 
            // Prestag
            // 
            this.Prestag.AutoSize = true;
            this.Prestag.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Prestag.Location = new System.Drawing.Point(30, 185);
            this.Prestag.Name = "Prestag";
            this.Prestag.Size = new System.Drawing.Size(116, 29);
            this.Prestag.TabIndex = 26;
            this.Prestag.Text = "President";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 36);
            this.label1.TabIndex = 27;
            this.label1.Text = "_________";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // vptag
            // 
            this.vptag.AutoSize = true;
            this.vptag.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vptag.Location = new System.Drawing.Point(31, 325);
            this.vptag.Name = "vptag";
            this.vptag.Size = new System.Drawing.Size(169, 29);
            this.vptag.TabIndex = 28;
            this.vptag.Text = "Vice President";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 325);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 36);
            this.label3.TabIndex = 29;
            this.label3.Text = "_________";
            // 
            // sectag
            // 
            this.sectag.AutoSize = true;
            this.sectag.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sectag.Location = new System.Drawing.Point(30, 486);
            this.sectag.Name = "sectag";
            this.sectag.Size = new System.Drawing.Size(115, 29);
            this.sectag.TabIndex = 30;
            this.sectag.Text = "Secretary";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 488);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 36);
            this.label4.TabIndex = 31;
            this.label4.Text = "_________";
            // 
            // auditag
            // 
            this.auditag.AutoSize = true;
            this.auditag.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.auditag.Location = new System.Drawing.Point(359, 185);
            this.auditag.Name = "auditag";
            this.auditag.Size = new System.Drawing.Size(89, 29);
            this.auditag.TabIndex = 32;
            this.auditag.Text = "Auditor";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(358, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 36);
            this.label5.TabIndex = 33;
            this.label5.Text = "_________";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(359, 325);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 29);
            this.label2.TabIndex = 34;
            this.label2.Text = "Treasurer";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(358, 325);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 36);
            this.label6.TabIndex = 35;
            this.label6.Text = "_________";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(361, 486);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(252, 29);
            this.label7.TabIndex = 36;
            this.label7.Text = "Public Relation Officer";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(358, 486);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(168, 36);
            this.label8.TabIndex = 37;
            this.label8.Text = "_________";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.Location = new System.Drawing.Point(35, 224);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(256, 98);
            this.dataGridView1.TabIndex = 38;
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView2.Location = new System.Drawing.Point(354, 224);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(256, 98);
            this.dataGridView2.TabIndex = 39;
            // 
            // dataGridView3
            // 
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView3.Location = new System.Drawing.Point(35, 364);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(256, 98);
            this.dataGridView3.TabIndex = 40;
            // 
            // dataGridView4
            // 
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView4.Location = new System.Drawing.Point(357, 364);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.RowTemplate.Height = 24;
            this.dataGridView4.Size = new System.Drawing.Size(256, 98);
            this.dataGridView4.TabIndex = 41;
            // 
            // dataGridView5
            // 
            this.dataGridView5.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView5.Location = new System.Drawing.Point(35, 535);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 51;
            this.dataGridView5.RowTemplate.Height = 24;
            this.dataGridView5.Size = new System.Drawing.Size(256, 98);
            this.dataGridView5.TabIndex = 42;
            // 
            // dataGridView6
            // 
            this.dataGridView6.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView6.Location = new System.Drawing.Point(357, 530);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowHeadersWidth = 51;
            this.dataGridView6.RowTemplate.Height = 24;
            this.dataGridView6.Size = new System.Drawing.Size(256, 98);
            this.dataGridView6.TabIndex = 43;
            // 
            // Retrieve_tab
            // 
            this.Retrieve_tab.BackColor = System.Drawing.SystemColors.Highlight;
            this.Retrieve_tab.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Retrieve_tab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Retrieve_tab.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Retrieve_tab.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Retrieve_tab.Location = new System.Drawing.Point(477, 114);
            this.Retrieve_tab.Name = "Retrieve_tab";
            this.Retrieve_tab.Size = new System.Drawing.Size(122, 35);
            this.Retrieve_tab.TabIndex = 44;
            this.Retrieve_tab.Text = "Retrieve";
            this.Retrieve_tab.UseVisualStyleBackColor = false;
            this.Retrieve_tab.Click += new System.EventHandler(this.Retrieve_tab_Click);
            // 
            // Admintabulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 645);
            this.Controls.Add(this.Retrieve_tab);
            this.Controls.Add(this.dataGridView6);
            this.Controls.Add(this.dataGridView5);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.auditag);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.sectag);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.vptag);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Prestag);
            this.Controls.Add(this.tabulationpage);
            this.Controls.Add(this.label2__);
            this.Controls.Add(this.AdminNavigation);
            this.Controls.Add(this.Tabtopred);
            this.Controls.Add(this.label1);
            this.Name = "Admintabulation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admintabulation";
            ((System.ComponentModel.ISupportInitialize)(this.Tabtopred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AdminNavigation;
        private System.Windows.Forms.PictureBox Tabtopred;
        private System.Windows.Forms.Label tabulationpage;
        private System.Windows.Forms.Label label2__;
        private System.Windows.Forms.Label Prestag;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label vptag;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label sectag;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label auditag;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.Button Retrieve_tab;
    }
}