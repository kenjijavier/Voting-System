﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Voting_System
{
    public partial class AdminNav : Form
    {
        public AdminNav()
        {
            InitializeComponent();
        }

        private void logout_label_Click(object sender, EventArgs e)
        {
            Adminlogin adlogout = new Adminlogin();
            adlogout.Show();
            this.Hide();
        }

        private void tab_label_Click(object sender, EventArgs e)
        {
            Admintabulation adtab = new Admintabulation();
            adtab.Show();
            this.Hide();
        }

        private void vote_label_Click(object sender, EventArgs e)
        {
            Admincandidates adcand = new Admincandidates();
            adcand.Show();
            this.Hide();
        }

        private void voters_lbl_Click(object sender, EventArgs e)
        {
            Adminvoters advote = new Adminvoters();
            advote.Show();
            this.Hide();
        }

        private void adminnavigation_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are already in the Navigation Menu.");
        }
    }
}
