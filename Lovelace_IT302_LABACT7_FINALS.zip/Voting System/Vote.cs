﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Voting_System
{
    
    public partial class Vote : Form
    {
        private string connectionString = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=voteDB.mdb";
        public Vote()
        {
            InitializeComponent();

        }

        private void navigation_Click(object sender, EventArgs e)
        {
            Usernavigation f4 = new Usernavigation();
            f4.Show();
            this.Hide();
        }

        private void get_btn_Click(object sender, EventArgs e)
        {
            string query = "SELECT name FROM tbl_candidate";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    OleDbCommand command = new OleDbCommand(query, connection);
                    OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "name";
                    comboBox2.DataSource = dt;
                    comboBox2.DisplayMember = "name";
                    comboBox3.DataSource = dt;
                    comboBox3.DisplayMember = "name";
                    comboBox4.DataSource = dt;
                    comboBox4.DisplayMember = "name";
                    comboBox5.DataSource = dt;
                    comboBox5.DisplayMember = "name";
                    comboBox6.DataSource = dt;
                    comboBox6.DisplayMember = "name";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            comboBox4.Text = "";
            comboBox5.Text = "";
            comboBox6.Text = "";
        }

        private void confirm_btn_Click(object sender, EventArgs e)
        {
            Userhomepage home = new Userhomepage();
            home.Show();
            this.Hide();
            MessageBox.Show("Vote Recorded! Thank you for Voting!");
        }
    }
}
