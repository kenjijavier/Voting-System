﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Voting_System
{
    public partial class Admintabulation : Form
    {
        private string connectionString = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=voteDB.mdb";

        public Admintabulation()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Retrieve_tab_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    string query = "SELECT * FROM tbl_candidate";
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn))
                    {
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                        dataGridView2.DataSource = table;
                        dataGridView3.DataSource = table;
                        dataGridView4.DataSource = table;
                        dataGridView5.DataSource = table;
                        dataGridView6.DataSource = table;
                    }
                }
            }
            catch (OleDbException oleDbEx)
            {
                MessageBox.Show("OleDbException: " + oleDbEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

        }

        private void AdminNavigation_Click(object sender, EventArgs e)
        {
            AdminNav adNav = new AdminNav();
            adNav.Show();
            this.Hide();
        }
    }
}
