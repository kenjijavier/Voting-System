﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Voting_System
{
    public partial class Adminvoters : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=voteDB.mdb");
        OleDbCommand cmd = new OleDbCommand();
        public Adminvoters()
        {
            InitializeComponent();
        }

        private void Adminnavigation_Click(object sender, EventArgs e)
        {
            AdminNav adNav = new AdminNav();
            adNav.Show();
            this.Hide();
        }

        private void Retrieve_voters_Click(object sender, EventArgs e)
        {
            string query = "SELECT firstname, lastname, email,password FROM tbl_user";
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, con))
            {
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }
    }
}
