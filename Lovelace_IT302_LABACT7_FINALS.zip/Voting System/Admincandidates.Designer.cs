﻿namespace Voting_System
{
    partial class Admincandidates
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.AdminnavCand = new System.Windows.Forms.Button();
            this.candidatespage = new System.Windows.Forms.Label();
            this.label2_ = new System.Windows.Forms.Label();
            this.Add_btn_cand = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Retrieve_cand = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pictureBox1.Location = new System.Drawing.Point(-2, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(625, 98);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // AdminnavCand
            // 
            this.AdminnavCand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.AdminnavCand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AdminnavCand.Location = new System.Drawing.Point(12, 22);
            this.AdminnavCand.Name = "AdminnavCand";
            this.AdminnavCand.Size = new System.Drawing.Size(47, 56);
            this.AdminnavCand.TabIndex = 18;
            this.AdminnavCand.Text = "___\r\n___\r\n___\r\n";
            this.AdminnavCand.UseVisualStyleBackColor = false;
            this.AdminnavCand.Click += new System.EventHandler(this.AdminnavCand_Click);
            // 
            // candidatespage
            // 
            this.candidatespage.AutoSize = true;
            this.candidatespage.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.candidatespage.Location = new System.Drawing.Point(25, 98);
            this.candidatespage.Name = "candidatespage";
            this.candidatespage.Size = new System.Drawing.Size(270, 54);
            this.candidatespage.TabIndex = 20;
            this.candidatespage.Text = "Candidates";
            // 
            // label2_
            // 
            this.label2_.AutoSize = true;
            this.label2_.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2_.Location = new System.Drawing.Point(1, 133);
            this.label2_.Name = "label2_";
            this.label2_.Size = new System.Drawing.Size(610, 36);
            this.label2_.TabIndex = 21;
            this.label2_.Text = "___________________________________";
            // 
            // Add_btn_cand
            // 
            this.Add_btn_cand.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Add_btn_cand.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Add_btn_cand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Add_btn_cand.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_btn_cand.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Add_btn_cand.Location = new System.Drawing.Point(474, 113);
            this.Add_btn_cand.Name = "Add_btn_cand";
            this.Add_btn_cand.Size = new System.Drawing.Size(86, 35);
            this.Add_btn_cand.TabIndex = 22;
            this.Add_btn_cand.Text = "Add";
            this.Add_btn_cand.UseVisualStyleBackColor = false;
            this.Add_btn_cand.Click += new System.EventHandler(this.Add_btn_cand_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.Location = new System.Drawing.Point(43, 203);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(526, 403);
            this.dataGridView1.TabIndex = 23;
            // 
            // Retrieve_cand
            // 
            this.Retrieve_cand.BackColor = System.Drawing.SystemColors.Highlight;
            this.Retrieve_cand.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Retrieve_cand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Retrieve_cand.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Retrieve_cand.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Retrieve_cand.Location = new System.Drawing.Point(346, 113);
            this.Retrieve_cand.Name = "Retrieve_cand";
            this.Retrieve_cand.Size = new System.Drawing.Size(122, 35);
            this.Retrieve_cand.TabIndex = 24;
            this.Retrieve_cand.Text = "Retrieve";
            this.Retrieve_cand.UseVisualStyleBackColor = false;
            this.Retrieve_cand.Click += new System.EventHandler(this.Retrieve_cand_Click);
            // 
            // Admincandidates
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 645);
            this.Controls.Add(this.Retrieve_cand);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Add_btn_cand);
            this.Controls.Add(this.candidatespage);
            this.Controls.Add(this.label2_);
            this.Controls.Add(this.AdminnavCand);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Admincandidates";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admincandidates";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button AdminnavCand;
        private System.Windows.Forms.Label candidatespage;
        private System.Windows.Forms.Label label2_;
        private System.Windows.Forms.Button Add_btn_cand;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Retrieve_cand;
    }
}