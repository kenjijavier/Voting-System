﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Voting_System
{
    public partial class Admincandidates : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=voteDB.mdb");
        OleDbCommand cmd = new OleDbCommand();
        public Admincandidates()
        {
            InitializeComponent();
        }

        private void AdminnavCand_Click(object sender, EventArgs e)
        {
            AdminNav adNav = new AdminNav();
            adNav.Show();
            this.Hide();
        }

        private void Add_btn_cand_Click(object sender, EventArgs e)
        {
            Addcandidate addcand = new Addcandidate();
            addcand.Show();
            this.Hide();
        }

        private void Retrieve_cand_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM tbl_candidate";
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, con))
            {
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }
    }
}
