﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Voting_System
{
    public partial class Addcandidate : Form
    {
        private string connectionString = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=voteDB.mdb";
        public Addcandidate()
        {
            InitializeComponent();
        }

        private void Candidate_fn_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Cand_name_lbl.Text))
            {
                Cand_name_lbl.Visible = true;
            }
            else
            {
                Cand_name_lbl.Visible = false;
            }
        }
        private void Partyname_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(partylabel.Text))
            {
                partylabel.Visible = true;
            }
            else
            {
                partylabel.Visible = false;
            }
        }

        private void Cand_add_Click(object sender, EventArgs e)
        {
            if (Cand_Name.Text == "" || Positiondd.Text == "" || Partyname.Text == "")
            {
                MessageBox.Show("Fields are not all completed yet.");
            }
            else
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    string query = "INSERT INTO tbl_candidate (name, [position], party) VALUES (@Name, @Position, @Party)";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", Cand_Name.Text);
                        cmd.Parameters.AddWithValue("@Position", Positiondd.Text);
                        cmd.Parameters.AddWithValue("@Party", Partyname.Text);
                        conn.Open();
                        int result = cmd.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Registration successful!");
                        }
                        else
                        {
                            MessageBox.Show("Registration failed.");
                        }
                    }
                   
                }
            }
        }

        private void Cand_cancel_Click(object sender, EventArgs e)
        {
            Admincandidates back = new Admincandidates();
            back.Show();
            this.Hide();
        }
    }
}
