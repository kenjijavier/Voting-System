﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Voting_System
{
    public partial class Adminlogin : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=voteDB.mdb");
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter ada = new OleDbDataAdapter();
        public Adminlogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Userloginpage a1 = new Userloginpage();
            a1.Show();
            this.Hide();
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            con.Open();
            string login = "SELECT * FROM tbl_admin WHERE username='" + userlog.Text + "' and password='" + pwordlog.Text + "'";
            cmd = new OleDbCommand(login, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (userlog.Text == "" && pwordlog.Text == "")
            {
                MessageBox.Show("Error. Account not Found.");
            }
            else if (dr.Read() == true)
            {
                AdminNav admenu = new AdminNav();
                admenu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Error");
            }
            con.Close();
        }

        private void userlog_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(userlog.Text))
            {
                Userlog_label.Visible = true;
            }
            else
            {
                Userlog_label.Visible = false;
            }
        }

        private void pwordlog_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(pwordlog.Text))
            {
                Pword_label.Visible = true;
            }
            else
            {
                Pword_label.Visible = false;
            }
        }
    }
}
