﻿namespace Voting_System
{
    partial class AdminNav
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.__ = new System.Windows.Forms.Label();
            this._ = new System.Windows.Forms.Label();
            this.___ = new System.Windows.Forms.Label();
            this.voters_lbl = new System.Windows.Forms.Label();
            this.vote_label = new System.Windows.Forms.Label();
            this.tab_label = new System.Windows.Forms.Label();
            this.adminnavigation = new System.Windows.Forms.Button();
            this.Logout_lbl = new System.Windows.Forms.Label();
            this.adminname = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.__);
            this.groupBox2.Controls.Add(this._);
            this.groupBox2.Controls.Add(this.___);
            this.groupBox2.Controls.Add(this.voters_lbl);
            this.groupBox2.Controls.Add(this.vote_label);
            this.groupBox2.Controls.Add(this.tab_label);
            this.groupBox2.Location = new System.Drawing.Point(50, 93);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(510, 574);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // __
            // 
            this.__.AutoSize = true;
            this.__.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.__.Location = new System.Drawing.Point(29, 275);
            this.__.Name = "__";
            this.__.Size = new System.Drawing.Size(457, 36);
            this.__.TabIndex = 17;
            this.__.Text = "__________________________";
            // 
            // _
            // 
            this._.AutoSize = true;
            this._.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._.Location = new System.Drawing.Point(29, 174);
            this._.Name = "_";
            this._.Size = new System.Drawing.Size(457, 36);
            this._.TabIndex = 16;
            this._.Text = "__________________________";
            // 
            // ___
            // 
            this.___.AutoSize = true;
            this.___.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.___.Location = new System.Drawing.Point(29, 81);
            this.___.Name = "___";
            this.___.Size = new System.Drawing.Size(457, 36);
            this.___.TabIndex = 15;
            this.___.Text = "__________________________";
            // 
            // voters_lbl
            // 
            this.voters_lbl.AutoSize = true;
            this.voters_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.voters_lbl.Location = new System.Drawing.Point(27, 229);
            this.voters_lbl.Name = "voters_lbl";
            this.voters_lbl.Size = new System.Drawing.Size(136, 46);
            this.voters_lbl.TabIndex = 14;
            this.voters_lbl.Text = "Voters";
            // 
            // vote_label
            // 
            this.vote_label.AutoSize = true;
            this.vote_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vote_label.Location = new System.Drawing.Point(27, 137);
            this.vote_label.Name = "vote_label";
            this.vote_label.Size = new System.Drawing.Size(221, 46);
            this.vote_label.TabIndex = 13;
            this.vote_label.Text = "Candidates";
            // 
            // tab_label
            // 
            this.tab_label.AutoSize = true;
            this.tab_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_label.Location = new System.Drawing.Point(27, 44);
            this.tab_label.Name = "tab_label";
            this.tab_label.Size = new System.Drawing.Size(206, 46);
            this.tab_label.TabIndex = 12;
            this.tab_label.Text = "Tabulation";
            // 
            // adminnavigation
            // 
            this.adminnavigation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.adminnavigation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adminnavigation.Location = new System.Drawing.Point(12, 12);
            this.adminnavigation.Name = "adminnavigation";
            this.adminnavigation.Size = new System.Drawing.Size(47, 56);
            this.adminnavigation.TabIndex = 18;
            this.adminnavigation.Text = "___\r\n___\r\n___\r\n";
            this.adminnavigation.UseVisualStyleBackColor = false;
            // 
            // Logout_lbl
            // 
            this.Logout_lbl.AutoSize = true;
            this.Logout_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logout_lbl.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Logout_lbl.Location = new System.Drawing.Point(428, 32);
            this.Logout_lbl.Name = "Logout_lbl";
            this.Logout_lbl.Size = new System.Drawing.Size(108, 36);
            this.Logout_lbl.TabIndex = 20;
            this.Logout_lbl.Text = "Logout";
            this.Logout_lbl.Click += new System.EventHandler(this.logout_label_Click);
            // 
            // adminname
            // 
            this.adminname.AutoSize = true;
            this.adminname.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminname.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.adminname.Location = new System.Drawing.Point(86, 20);
            this.adminname.Name = "adminname";
            this.adminname.Size = new System.Drawing.Size(138, 46);
            this.adminname.TabIndex = 19;
            this.adminname.Text = "Admin";
            // 
            // AdminNav
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(622, 645);
            this.Controls.Add(this.Logout_lbl);
            this.Controls.Add(this.adminname);
            this.Controls.Add(this.adminnavigation);
            this.Controls.Add(this.groupBox2);
            this.Name = "AdminNav";
            this.Text = "AdminNav";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label __;
        private System.Windows.Forms.Label _;
        private System.Windows.Forms.Label ___;
        private System.Windows.Forms.Label voters_lbl;
        private System.Windows.Forms.Label vote_label;
        private System.Windows.Forms.Label tab_label;
        private System.Windows.Forms.Button adminnavigation;
        private System.Windows.Forms.Label Logout_lbl;
        private System.Windows.Forms.Label adminname;
    }
}